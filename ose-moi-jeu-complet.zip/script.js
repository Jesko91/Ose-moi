const cards = [
  { level: "Niveau 1 : Soft & Séduction", text: "Fais un clin d’œil à la personne de ton choix.", class: "level-1" },
  { level: "Niveau 1 : Soft & Séduction", text: "Pose une question drôle à ton voisin de droite.", class: "level-1" },
  { level: "Niveau 2 : Tension & Provocation", text: "Choisis quelqu’un et pose-lui une question sexy.", class: "level-2" },
  { level: "Niveau 2 : Tension & Provocation", text: "Regarde intensément un joueur pendant 10 secondes.", class: "level-2" },
  { level: "Niveau 3 : Very Hot & No Limit", text: "Fais un gage torride à un joueur (ex : susurrer quelque chose).", class: "level-3" },
  { level: "Niveau 3 : Very Hot & No Limit", text: "Décris ton fantasme le plus fou.", class: "level-3" },
  { level: "Niveau 4 : Désirs & Choix", text: "Choisis une personne et dis 3 choses que tu adores chez elle.", class: "level-4" },
  { level: "Niveau 4 : Désirs & Choix", text: "Avec qui ici pourrais-tu passer une nuit torride ? Explique pourquoi.", class: "level-4" }
];

let currentIndex = 0;

function nextCard() {
  const card = cards[currentIndex % cards.length];
  const cardDiv = document.getElementById('card');

  // Réinitialise les classes
  cardDiv.className = "";
  void cardDiv.offsetWidth; // trick to restart animation

  // Applique la classe du niveau
  cardDiv.classList.add("fade-in", card.class);

  document.getElementById('level').textContent = card.level;
  document.getElementById('question').textContent = card.text;
  currentIndex++;
}
